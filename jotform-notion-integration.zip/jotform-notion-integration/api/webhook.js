export default async function handler(req, res) {
  // Aceita apenas POST
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }

  try {
    const { rawRequest } = req.body;
    
    // Extrai os campos do JotForm
    const fields = {};
    Object.keys(rawRequest).forEach(key => {
      if (key.startsWith('q')) {
        const field = rawRequest[key];
        fields[key] = field;
      }
    });

    // Monta propriedades do Notion
    const properties = {
      "Nome": {
        title: [{ text: { content: fields.q3_nomeDo || "Sem nome" } }]
      },
      "Data": {
        date: { start: fields.q4_data || new Date().toISOString().split('T')[0] }
      },
      "Relato": {
        rich_text: [{ text: { content: fields.q5_relato || "" } }]
      },
      "Atividade prática": {
        rich_text: [{ text: { content: fields.q6_atividadePratica || "" } }]
      },
      "Atendimento individual": {
        rich_text: [{ text: { content: fields.q7_atendimentoIndividual || "" } }]
      }
    };

    // Anexo (link do arquivo)
    if (fields.q8_anexoDe && Array.isArray(fields.q8_anexoDe) && fields.q8_anexoDe.length > 0) {
      properties["Anexo"] = {
        url: fields.q8_anexoDe[0]
      };
    }

    // Envia para Notion
    const notionResponse = await fetch('https://api.notion.com/v1/pages', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer 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`,
        'Content-Type': 'application/json',
        'Notion-Version': '2022-06-28'
      },
      body: JSON.stringify({
        parent: { database_id: '357ec500a6fc808e8c03d26a5e7b7ef0' },
        properties
      })
    });

    if (!notionResponse.ok) {
      const errorData = await notionResponse.json();
      console.error('Erro Notion:', errorData);
      return res.status(500).json({ error: 'Erro ao criar página no Notion', details: errorData });
    }

    return res.status(200).json({ success: true, message: 'Relatório enviado ao Notion' });

  } catch (error) {
    console.error('Erro geral:', error);
    return res.status(500).json({ error: 'Erro no servidor', details: error.message });
  }
}
