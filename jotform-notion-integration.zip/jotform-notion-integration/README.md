# JotForm → Notion Integration

Integração serverless para enviar formulários do JotForm para database Notion via Vercel.

## Estrutura

```
api/
└── webhook.js  → Endpoint que recebe dados do JotForm e envia para Notion
```

## Deploy

1. Faça upload deste repositório no GitHub
2. Conecte no Vercel (vercel.com)
3. Deploy automático

## Webhook URL

Após deploy, use: `https://SEU-PROJETO.vercel.app/api/webhook`

Configure esta URL no JotForm (Settings → Integrations → Webhooks)

## Importante

- Os IDs dos campos (q3_nomeDo, q4_data, etc.) podem estar errados
- Após primeiro teste, verifique os logs do Vercel para confirmar os IDs corretos
- Ajuste o código se necessário

## Database Notion

- Database ID: 357ec500a6fc808e8c03d26a5e7b7ef0
- Colunas: Nome, Data, Relato, Atividade prática, Atendimento individual, Anexo
